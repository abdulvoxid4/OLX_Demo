//
//  AddViewController.swift
//  OLX1
//
//  Created by Abdulvoxid on 30/03/24.
//

import UIKit

final class AddViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .white
    }
}
